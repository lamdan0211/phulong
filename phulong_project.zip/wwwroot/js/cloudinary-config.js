

export const CLOUDINARY_CONFIG = {
  cloudName: 'drlpx4bw5',

  uploadPreset: 'phulong_unsigned',

  folder: 'phulong-images',

  tags: ['website', 'admin-upload']
};

