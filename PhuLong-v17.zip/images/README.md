# Images Folder

Thư mục này dùng để lưu hình ảnh mẫu (nếu có).

Hệ thống sẽ tự động upload hình lên Firebase Storage khi bạn sử dụng admin tool.

## Lưu ý:
- Hình ảnh sẽ được lưu trên Firebase Storage, không cần commit vào Git
- Kích thước khuyến nghị:
  - Hero image: 1200x600px
  - About image: 800x600px
  - Portfolio items: 600x400px
- Format: JPG, PNG, WebP
- Dung lượng tối đa mỗi file: 5MB
